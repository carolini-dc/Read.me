<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=#fff&height=120&section=header"/>


[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=FFF&size=35&center=true&vCenter=true&width=1000&lines=Hello,+my+name+is+Carolini;I'm+25+years+old;I'm+from+Brazil;I'm+a+programming+student;The+future+is+today;Be+Welcome!+:%29)](https://git.io/typing-svg)<br><br><br>
<div align="center">  
  <img width="49%" height="195px" src="https://github-readme-stats.vercel.app/api?username=caroliniicristini&show_icons=true&count_private=true&hide_border=true&title_color=fff&icon_color=fff&text_color=c9d1d9&bg_color=0d1117" alt="Carolini github stats" />
  <img width="41%" height="195px" src="https://github-readme-stats.vercel.app/api/top-langs/?username=caroliniicristini&layout=compact&hide_border=true&title_color=fff&text_color=fff&bg_color=0d1117" />
</div>
<br>


 
 <hr>
  <div style="display: inline_block">
    <h3>Skills → Front-end</h3>
    <img align="center" alt="Carolini-HTML" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg">-
    <img align="center" alt="Carolini-CSS" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg">-
    <img align="center" alt="Carolini-CSS" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/sass/sass-original.svg">-
    <img align="center" alt="Carolini-Js" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg">-
    <img align="center" alt="Carolini-Figma" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original.svg">-
    <img align="center" alt="Carolini-Figma" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg">
  </div>
<hr>

<div style="display: inline_block">
  <h3>My Design Tools</h3>
  <img align="center" alt="Carolini-Figma" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/figma/figma-original.svg">
</div>
<hr>
<div>
  <h3>Studying in this Moment:</h3>
  <img align="center" alt="Carolini-React" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg">
</div>

<hr>
<div style="display: inline_block">
  <h3>Anothers</h3>
  <img align="center" alt="Carolini-Windows" height="40" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/windows8/windows8-original.svg"> -
  <img align="center" alt="Carolini-Git" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg">-
  <img align="center" alt="Carolini-VSCode" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg">-
  <img align="center" alt="Carolini-GitHub" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/github/github-original.svg">
</div>

<hr>
<div> 

<a href="https://www.linkedin.com/in/carolini-c" target="_blank">
  <img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" style="border-radius: 30px" target="_blank">
</a> 
  <a href = "mailto:carolinicristini1@gmail.com"> <img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-     badge&logo=gmail&logoColor=white" target="_blank"></a>
</div>
<hr><br>
<div align="center">
  <br><p align="centre"><b>Visitors Count</b></p>  
  <p align="center"><img width="19%" align="center" src="https://profile-counter.glitch.me/{caroliniicristini}/count.svg" /></p> 
  <br>
</div>
